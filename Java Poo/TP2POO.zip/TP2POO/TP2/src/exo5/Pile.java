package exo5;

public class Pile {
    private Maillon sommet;
    Maillon m = new Maillon();
    public void empiler(String s){
        sommet = new Maillon(s, sommet);
    }
    public String depiler (){
        if (sommet == null){
            return null;
        } else {
            String valeur = sommet.getValeur();
            sommet = sommet.getSuivant();
            return valeur;
        }
    }
    public Maillon getSommet(){
        return sommet;
    }
    public boolean estVide(){
        if (sommet == null){
            return true;
        } else {
            return false;
        }
    }

}
