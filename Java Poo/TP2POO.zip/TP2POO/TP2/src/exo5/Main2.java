package exo5;

public class Main2 {
    public static void main(String[] args) {
        Maillon e;
        String d;
        Pile pile = new Pile();
        // empile les 5 premières lettres de l'alphabet
        for (int i = 0;i<5;i++) {
            pile.empiler(String.valueOf( (int) (Math.random()*100)));
        }
        // affiche le contenu de la pile
        e = pile.getSommet();
        while (e != null){
            System.out.println(e.getValeur());
            e = e.getSuivant();
        }
        System.out.println();
        // dépile deux fois de suite
        d= pile.depiler();
        d= pile.depiler();
        // affiche le contenu de la pile
        e = pile.getSommet();
        while (e != null){
            System.out.println(e.getValeur());
            e = e.getSuivant();

        }
    }
}
// l' encapsulation n'est pas respectée car le getSommet() permet d'accéder à toute la pile

//Pour afficher le contenu de la pile, redéfinir méthode toString()

//Pour afficher le contenu de la pile, redéfinir méthode toString()

