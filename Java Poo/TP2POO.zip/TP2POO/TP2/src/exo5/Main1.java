package exo5;

public class Main1 {
    public static void main(String[] args) {
        Maillon e;
        String d;
        Pile pile = new Pile();
        // empile les 5 premières lettres de l'alphabet
        String[] alphabet = {"a","b","c","d","e"};
        for (String i:alphabet) {
            pile.empiler(i);
        }
        // affiche le contenu de la pile
        e = pile.getSommet();
        while (e != null){
            System.out.println(e.getValeur());
            e = e.getSuivant();
        }
        System.out.println();
        // dépile deux fois de suite
        d= pile.depiler();
        d= pile.depiler();
        // affiche le contenu de la pile
        e = pile.getSommet();
        while (e != null){
            System.out.println(e.getValeur());
            e = e.getSuivant();

        }
    }
}
// l' encapsulation n'est pas respectée car le getSommet() permet d'accéder à toute la pile
// de plus cela complique le code car il faut travailler avec les maillons

