package exo1;

public class Client {
    private int idClient;
    private String nom;
    private String prenom;
    private String Societe;
    private boolean actif;

    private static  int numerosuivant = 1;
    {this.idClient = numerosuivant++;}
    public Client(int idClient, String nom) {
        this.nom = nom;
    }

    public Client(int idClient, String nom, String prenom, String societe, boolean actif) {
        this(idClient,nom);
        this.prenom = prenom;
        Societe = societe;
        this.actif = actif;
    }

    public int getIdClient(){
        return idClient;
    }
    public String getNom(){
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getSociete() {
        return Societe;
    }

    public boolean isActif() {
        return actif;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setSociete(String societe) {
        Societe = societe;
    }

    public void setActif(boolean actif) {
        this.actif = actif;
    }
}
