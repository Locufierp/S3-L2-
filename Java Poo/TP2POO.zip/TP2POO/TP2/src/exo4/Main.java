package exo4;

import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        int number = 1;
        while (number > 0){
            boolean scanpos = false;
            while (!scanpos) {
                System.out.print("somme jusqu'a ");
                while (!scan.hasNextInt()) {
                    System.out.println("pas un int");
                    scan.next();
                    System.out.print("somme jusqu'a ");
                }
                number = scan.nextInt();
                if (number >= 0) {
                    scanpos = true;
                }
            }
            if (number != 0) {
                int somme = 0;
                for (int i = 0; i <= number; i++) {
                    somme += i;
                }
                System.out.println(somme);;
            }
        }
        System.out.println("fin");
    }
}
