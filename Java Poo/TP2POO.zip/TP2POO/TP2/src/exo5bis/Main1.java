package exo5bis;

public class Main1 {
    public static void main(String[] args) {
        String d;
        Pile pile = new Pile();
        // empile les 5 premières lettres de l'alphabet
        String[] alphabet = {"a","b","c","d","e"};
        for (String i:alphabet) {
            pile.empiler(i);
        }
        // affiche le contenu de la pile
        System.out.println(pile.toString());
        System.out.println();
        // dépile deux fois de suite
        pile.depiler();
        pile.depiler();
        // affiche le contenu de la pile
        System.out.println(pile.toString());
    }
}

