package exo2;

public class Main {
    public static void main(String[] args) {
        Temps temps=new Temps(100,120,60000);
        System.out.println(temps.getHeures() + " " + temps.getMinutes() + " " + temps.getSecondes());
    }

}
