package exo2;

public class Temps {
    long heures;
    int minutes,secondes;

    public Temps() {
    }

    public Temps(long heures, int minutes, int secondes) {
        this.heures = heures;
        this.minutes = minutes;
        this.secondes = secondes;
        normaliser();
    }

    public Temps(long t) {
        this.heures = t/3600;
        this.minutes = (int) ((t/60)%60);
        this.secondes = (int) t%60;
    }

    public long getHeures() {
        return heures;
    }

    public int getMinutes() {
        return minutes;
    }

    public int getSecondes() {
        return secondes;
    }

    private void normaliser(){
        minutes = minutes + secondes /60;
        secondes = secondes % 60;
        heures = heures + minutes / 60;
        minutes = minutes % 60;
        // this.heures += this.secondes/3600+this.minutes/60;
        // this.minutes +=  (this.secondes/60)%60 - (this.minutes/60)*60;
        // this.secondes -= (this.secondes/60)%60*60;

    }

    public long conversion(){
        return (long) 3600*this.heures+60*this.minutes+this.secondes;
    }

    public void ajouterTemps(Temps t){
        this.heures += t.getHeures();
        this.minutes += t.getMinutes();
        this.secondes += t.getSecondes();
        normaliser();
    }
}
