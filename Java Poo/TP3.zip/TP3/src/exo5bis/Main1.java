package exo5bis;

public class Main1 {
    public static void main(String[] args) {
        Pile pile = new Pile();
        // empile les 5 premières lettres de l'alphabet
        Object[] alphabet = {"a","b",4,"d",5,false};
        for (Object i:alphabet) {
            pile.empiler(i);
        }
        // affiche le contenu de la pile
        System.out.println(pile.toString());
        System.out.println();
        // dépile deux fois de suite
        pile.depiler();
        pile.depiler();
        // affiche le contenu de la pile
        System.out.println(pile.toString());
    }
}

