package exo5bis;

public class Maillon {
    private Object valeur;
    private Maillon suivant;
    public Maillon(Object s, Maillon m) {
        valeur = s;
        suivant = m;
    }

    public Maillon() {
    }
    public Object getValeur() {
        return valeur;
    }

    public Maillon getSuivant() {
        return suivant;
    }

    public void setValeur(Object valeur) {
        this.valeur = valeur;
    }

    public void setSuivant(Maillon suivant) {
        this.suivant = suivant;
    }

    public Maillon getMaillon(){
        return new Maillon(valeur,suivant);
    }

}
