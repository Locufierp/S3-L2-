package exo5bis;

public class Pile {
    private Maillon sommet;

    public void empiler(Object s){
        sommet = new Maillon(s, sommet);
    }
    public Object depiler (){
        if (sommet == null){
            return null;
        } else {
            Object valeur = sommet.getValeur();
            sommet = sommet.getSuivant();
            return valeur;
        }
    }
    public boolean estVide(){
        if (sommet == null){
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        Maillon e = sommet;
        String text = "[";
        while (e != null){
            text+= String.valueOf(e.getValeur())+",";
            e = e.getSuivant();
        }
        text+="]";
        return text;
    }
}
